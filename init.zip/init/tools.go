//go:build tools

package api

import (
	_ "github.com/golangci/golangci-lint/cmd/golangci-lint"
	_ "github.com/goware/modvendor"
)
