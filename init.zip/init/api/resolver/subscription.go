package resolver

type Subscription struct {
	r *Resolver
}
