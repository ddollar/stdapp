package resolver

type Mutation struct {
	r *Resolver
}
